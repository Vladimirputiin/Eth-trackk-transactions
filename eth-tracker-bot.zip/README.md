# ETH Tracker Bot

This bot tracks ETH, ERC-20 transactions, and contract calls for specified addresses and sends Telegram alerts.